/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: 38a1f5be85b4205ea9dfb48024e4e55b753cbdab */

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_Swoole_Coroutine_Scheduler_add, 0, 1, IS_VOID, 0)
	ZEND_ARG_TYPE_INFO(0, func, IS_CALLABLE, 0)
	ZEND_ARG_VARIADIC_TYPE_INFO(0, param, IS_MIXED, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_Swoole_Coroutine_Scheduler_parallel, 0, 2, IS_VOID, 0)
	ZEND_ARG_TYPE_INFO(0, n, IS_LONG, 0)
	ZEND_ARG_TYPE_INFO(0, func, IS_CALLABLE, 0)
	ZEND_ARG_VARIADIC_TYPE_INFO(0, param, IS_MIXED, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_Swoole_Coroutine_Scheduler_set, 0, 1, IS_VOID, 0)
	ZEND_ARG_TYPE_INFO(0, settings, IS_ARRAY, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_Swoole_Coroutine_Scheduler_getOptions, 0, 0, IS_ARRAY, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_Swoole_Coroutine_Scheduler_start, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()
